# Test Scenarios
| ID | Area | Scenario | Priority |
|---|---|---|---|
| TS-001 | Login | Valid admin login | P0 |
| TS-002 | Login | Invalid credentials | P0 |
| TS-003 | Assessment | Create valid assessment | P0 |
| TS-004 | Assessment | Empty title validation | P1 |
| TS-005 | Candidate | Submit valid answer | P0 |
| TS-006 | Candidate | Empty answer | P0 |
| TS-007 | AI | Score must be 0–100 | P0 |
| TS-008 | AI | Long answer | P1 |
| TS-009 | AI | Unicode/special characters | P1 |
| TS-010 | AI | Timeout/fallback | P0 |
| TS-011 | Results | UI/API consistency | P0 |
| TS-012 | Submission | Duplicate submission | P0 |
| TS-013 | Browser | Chromium/Firefox/WebKit | P1 |
