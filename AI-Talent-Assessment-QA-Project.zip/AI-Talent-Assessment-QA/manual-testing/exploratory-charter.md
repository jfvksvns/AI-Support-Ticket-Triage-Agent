# Exploratory Testing Charter

Think like a candidate, hiring manager and support engineer.

## Candidate experience
Explore assessment start, answer entry, submission and results. Look for confusing messages, lost data and duplicate submissions.

## AI evaluation
Try empty answers, very long answers, repeated answers, Unicode, special characters, misleading text and rapid repeated submissions. Check score validity and error handling.

## Admin workflow
Try unusual titles, zero/negative/large question counts, repeated clicks and browser refreshes.

Capture steps, expected/actual behavior, evidence, severity, reproducibility and business impact.
