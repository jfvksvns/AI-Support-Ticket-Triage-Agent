# Boundary Test Ideas

- Assessment title: empty, 1 char, minimum valid, maximum, maximum+1
- Question count: 0, 1, maximum, maximum+1, negative
- Candidate name: empty, 1 char, maximum, Unicode, special characters
- Answer: empty, 1 char, long input, Unicode, emoji, HTML-like text
- Score: 0, 1, 99, 100, negative, >100
- Submission: first click, double click, repeated submission
