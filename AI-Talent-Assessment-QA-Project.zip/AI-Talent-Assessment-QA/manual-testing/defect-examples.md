# Example Defect Records

## BUG-001 – AI score outside valid range
Severity: Critical | Priority: P1
Expected: Score must be 0–100. Actual: Score returned as 105. Impact: Incorrect candidate evaluation.

## BUG-002 – Duplicate submission
Severity: High | Priority: P1
Expected: Second submission should be blocked or idempotent. Actual: Two evaluations are created. Impact: Duplicate results.

## BUG-003 – Answer lost after refresh
Severity: Medium | Priority: P2
Expected: Saved answer recoverable. Actual: Answer lost. Impact: Poor candidate experience.
