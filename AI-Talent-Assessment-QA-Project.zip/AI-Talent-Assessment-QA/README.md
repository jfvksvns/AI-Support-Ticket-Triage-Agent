# AI Talent Assessment Platform – Complete QA Project

Production-style QA portfolio project for an AI-powered talent assessment workflow.

## Demonstrates
- Playwright UI automation and Page Object Model
- API testing with Playwright request API
- Functional, regression, smoke, negative, boundary and exploratory testing
- AI-specific validation: score range, long input, special characters, timeout/fallback and duplicate submission scenarios
- UI/API data consistency testing
- Parallel execution, retries and failure artifacts
- GitHub Actions CI/CD and nightly regression
- HTML reports, screenshots, video and traces on failure
- Manual QA documentation and defect examples

## Flow
Admin Login → Create Assessment → Candidate Submission → AI Evaluation → Results

## Run
```bash
npm install
npx playwright install
npm test
npm run smoke
npm run regression
npm run api
npm run report
```

The demo application is local and deterministic, so no paid AI API key is required.
